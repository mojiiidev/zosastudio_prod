<?php
// Silence is golden. This file is required but never seen by users due to redirects.
